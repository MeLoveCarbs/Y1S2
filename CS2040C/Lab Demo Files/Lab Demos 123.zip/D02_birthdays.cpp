#include <bits/stdc++.h>
using namespace std;

typedef tuple<int, int, int> triple;  // primitive data types that we combined and named as 'triple'

int main() {
  vector<triple> birthdays;                           // now we can do this

  birthdays.emplace_back(5, 24, -1980);
  birthdays.emplace_back(5, 24, -1982);               // reorder DD/MM/YYYY
  triple A = make_tuple(3, 10, -2017);                        // to MM, DD,
  triple B = make_tuple(11, 13, -1983);       // and then use NEGATIVE YYYY
  birthdays.push_back(B); // older way, use push_back; C++11-> emplace_back
  birthdays.push_back(A);
  birthdays.emplace_back(10, 24, -2011);
  birthdays.emplace_back(7, 16, -2014);
  birthdays.emplace_back(3, 31, -1951);
  birthdays.emplace_back(9, 2, -1950);

  sort(birthdays.begin(), birthdays.end());                // that's all :)
  for (auto &p: birthdays)
    printf("%d %d %d\n", get<1>(p), get<0>(p), -get<2>(p));  // negate YYYY

  return 0;
}

/*
// output should be
10 3 2017
31 3 1951
24 5 1982
24 5 1980
16 7 2014
2 9 1950
24 10 2011
13 11 1983
*/
