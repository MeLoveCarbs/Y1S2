// PS: THERE IS A MISSING PART INDICATED WITH "LAST PART"
// SUBMITTING THIS FILE VERBATIM TO KATTIS SHOULD BE WA

// Where's My Internet??
// Simple Graph DS (Adjacency List), Simple Graph Traversal, connectivity on unweighted graph

import java.io.*;
import java.util.*;

class wheresmyinternet {
  static ArrayList<ArrayList<Integer>> AL = new ArrayList<>(); // Adjacency List, preferably put as global variable as it will be accessed by the recursive DFS routine
  static ArrayList<Boolean> visited = new ArrayList<>(); // global variable for the same reason

  static void dfs(int u) { // the most basic standard DFS implementation, easy to memorize
    visited.set(u, true);
    for (Integer v : AL.get(u))
      if (!visited.get(v))
        dfs(v);
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String[] token = br.readLine().split(" ");
    int N = Integer.parseInt(token[0]), M = Integer.parseInt(token[1]); // 1 <= N, M <= 200000, rather big, but fine, N vertices and M edges

    // STORE the graph
    for (int a = 0; a < N; a++) // N rows, indexed [0..N-1]
      AL.add(new ArrayList<>());
    for (int i = 0; i < M; i++) { // O(M)
      token = br.readLine().split(" ");
      int a = Integer.parseInt(token[0])-1, b = Integer.parseInt(token[1])-1; // convert to 0-based indexing (otherwise you need N+1 rows in your Adjacency List)
      AL.get(a).add(b); // O(1)
      AL.get(b).add(a); // bi-directional
    }

    // EXPLORE the graph
    visited.addAll(Collections.nCopies(N, false)); // O(N)
    // dfs(0); // O(N+M), DFS version

    visited.set(0, true);
    Queue<Integer> Q = new LinkedList<>();
    Q.offer(0);
    while (!Q.isEmpty()) { // O(N+M), BFS version
      Integer u = Q.poll();
      for (Integer v : AL.get(u))
        if (!visited.get(v)) {
          visited.set(v, true);
          Q.offer(v);
        }
    }

    Boolean disconnected = false;
    // LAST PART START: PRINT the required answers (houses that are not connected to house 1) and adjust disconnected boolean flag accordingly





    // LAST PART END

    if (!disconnected)
      pw.println("Connected");

    pw.close();
  }
}
