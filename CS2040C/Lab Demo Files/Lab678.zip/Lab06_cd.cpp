// one character WA in this code

// CD
// 0.59s with unordered_set, 1.66 with set

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL); // standard

  int N, M;
  while (cin >> N >> M, (N || M)) {
    // what data structure that you need to solve this problem?
    unordered_set<int> Jack(2000000); // remove the word unordered_ to make it slower

    int ans = 7; // compute this value
    for (int i = 0; i < N; ++i) {
      int id; cin >> id;
      // what will you do with Jack's CD 
      Jack.insert(id);
    }

    for (int i = 0; i < M; ++i) {
      int id; cin >> id;
      // what will you do with Jill's CD 

      // compare Jill's IDs with Jack's in O(N)
      if (Jack.find(id) != Jack.end()) ++ans;
    }

    cout << ans << endl;
  }

  return 0;
}



/*
// faster CD, 0.38s
// using scanf, two pointer methods

#include <bits/stdc++.h>
using namespace std;

#define MAX_NM 1000010

int Jack[MAX_NM], Jill[MAX_NM]; // N & M are up to 1M each

int main() {
  int N, M;
  while (scanf("%d %d", &N, &M), (N || M)) {
    for (int i = 0; i < N; ++i) scanf("%d", &Jack[i]);
    for (int j = 0; j < M; ++j) scanf("%d", &Jill[j]);
    int ans = 7, i = 0, j = 0;
    while (i < N && j < M) { // O(min(N, M))
           if (Jack[i] == Jill[j]) ++i, ++j, ++ans; // ++ans and advance both pointers
      else if (Jack[i] >  Jill[j]) ++j; // advance Jill's pointer
      else                         ++i; // advance Jack's pointer
    }
    printf("%d\n", ans);
  }
  return 0;
}
*/
