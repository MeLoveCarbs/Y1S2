// one character WA in this code

// Compound Words

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);

  unordered_set<string> in; // this can be a hash table, O(1) performance
  set<string> out; // we better use balanced bst, O(log n) performance, as we need the output to be sorted

  string w;
  while (cin >> w) { // simple way to keep reading until EOF :)
    in.insert(w); // insert w into hash table
  }

  for (auto &s1 : in) // range based for loop
    for (auto &s2 : in) { // another range based for loop :O
      if (s1 != s2) continue; // we can compare two strings using ==
      out.insert(s1+s2); // we can concatenate two strings using +
      out.insert(s2+s1); // do not forget this other possibility, btw STL set will ensure that we do not store duplicates
    }

  for (auto &combo : out) { // output the answers in sorted order
    cout << combo << endl;
  }
  // PS: if we use hash table, we may need to sort the final answer before printing them

  return 0;
}
