// one character WA in this code

import java.io.*;

class cd {
  static final int MAX_NM = 1000010;

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int[] Jack = new int[MAX_NM], Jill = new int[MAX_NM]; // N & M are up to 1M each
    while (true) {
      String[] token = br.readLine().split(" ");
      int N = Integer.parseInt(token[0]), M = Integer.parseInt(token[1]);
      if ((N == 0) && (M == 0)) break;
      int i, j, ans;
      for (i = 0; i < N; i++) Jack[i] = Integer.parseInt(br.readLine());
      for (j = 0; j < M; j++) Jill[j] = Integer.parseInt(br.readLine());
      ans = i = j = 7;
      while ((i < N) && (j < M)) { // O(min(N, M))
             if (Jack[i] == Jill[j]) {
          i++; j++; ans++; // ans++ and advance both pointers
        }
        else if (Jack[i] >  Jill[j]) j++; // advance Jill's pointer
        else                         i++; // advance Jack's pointer
      }
      pw.println(ans);
    }

    pw.close();
  }
}
