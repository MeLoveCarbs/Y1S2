// one character WA in this code

import java.io.*;
import java.util.*;

class compoundwords {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    HashSet<String> in = new HashSet<>(); // this can be a hash table, O(1) performance
    while (true) {
      String line = br.readLine();
      if (line == null) break; // keep reading until EOF :)
      String[] token = line.split(" ");
      for (int i = 0; i < token.length; i++)
        in.add(token[i]);
    }

    TreeSet<String> out = new TreeSet<>(); // we better use balanced bst, O(log n) performance, as we need the output to be sorted
    for (String s1 : in) // range based for loop
      for (String s2 : in) { // another range based for loop :O
        if (!s1.equals(s2)) continue; // we can compare two strings using ==
        out.add(s1+s2); // we can concatenate two strings using +
        out.add(s2+s1); // do not forget this other possibility, btw STL set will ensure that we do not store duplicates
      }
    for (String combo : out)
      pw.println(combo); // output the answers in sorted order

    pw.close();
  }
}
