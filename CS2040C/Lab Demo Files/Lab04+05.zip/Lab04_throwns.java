// PS: THERE IS A MISSING PART INDICATED WITH "LAST PART"
// SUBMITTING THIS FILE VERBATIM TO KATTIS SHOULD BE WA

// Game of Throwns
// stack simulation, we use stack of positions of the egg holder to help us solve this problem

import java.io.*;
import java.util.*;

class Lab04_throwns {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String[] token = br.readLine().split(" ");
    int n = Integer.parseInt(token[0]), k = Integer.parseInt(token[1]); // 1 <= n <= 30 (number of students), 1 <= k <= 100 (number of commands from the teacher), just read

    // MAJOR HINT of the required data structure
    Stack<Integer> t = new Stack<>(); // stack t contains the stack of positions of the egg holder (so that we can undo later)
    t.push(0); // Child 0 always starts with the egg

    token = br.readLine().split(" ");
    int pos = 0;
    while (k-- > 0) { // now we throw the eggs around (or undo), O(k*(m+1)) = O(km), or O(kn), as m <= n in this problem (Daenerys never has the kids undo beyond the start of the game)
      int m;
      String cmd = token[pos++]; // we do not really know what comes next, is it a command "undo m" or a single integer, we read as string first
      if (cmd.equals("undo")) { // if we see a word "undo", then the format will be "undo m"
        m = Integer.parseInt(token[pos++]); // so we read m next
        
        // to undo last m commands, we...
        while (m-- > 0) { // simply pop from the last m egg positions (top m items of the stack), O(m) here
          t.pop();
        }
      }
      else { // this "cmd" is actually integer m :o
        m = Integer.parseInt(cmd); // convert string to integer
        
        // LAST PART START
        // when the teacher gives you a command p (-10000 <= p <= 10000)
        // push (the updated position of the egg, ensuring that the result is always [0..n-1]) to the top of the stack, O(1) here
        t.push(7); // THIS IS NOT THE CORRECT CODE, WHAT SHOULD YOU PUSH INTO THE STACK HERE?
        // LAST PART END
    }
    }

    // now what should be printed out at the end....
    int ans = t.peek(); // this should be the final position of the egg
    pw.println(ans);
    pw.close();
  }
}
