// Kattis's Quest
// this code has that overflow bug that has caught some students who almost got it AC, can you fix it to get AC?

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int N; cin >> N; cin.get();
  map<int, priority_queue<int>> pool;
  while (N--) {
    string S; cin >> S;
    if (S == "add") {
      int E, G; cin >> E >> G;
      pool[E].push(G);
    }
    else { // if (S == "get")
      int X; cin >> X;
      int ans = 0;
      while (X) {
        auto pos = pool.upper_bound(X); // find largest energy quest from current pool of quest
        if (pos == pool.begin()) break;
        --pos;
        X -= pos->first;
        priority_queue<int> &pq = pos->second;
        ans += pq.top(); pq.pop();
        if (pq.empty())
          pool.erase(pos);
      }
      cout << ans << endl;
    }
  }
  return 0;
}
