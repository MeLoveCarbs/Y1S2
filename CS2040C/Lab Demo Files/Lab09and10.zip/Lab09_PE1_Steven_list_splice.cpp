// Join Strings
// this code has that N=1 bug that has caught so many students, can you fix it to get AC?

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int N; cin >> N;
  list<string> S[N]; // array of N lists
  for (int i = 0; i < N; ++i) { // store in 0-based
    string Si; cin >> Si;
    S[i].push_back(Si);
  }
  int a, b;
  for (int i = 1; i <= N-1; ++i) { // process N-1 operations
    cin >> a >> b; --a; --b; // to 0-based indexing
    S[a].splice(S[a].end(), S[b]);
  }
  for (auto &Si : S[a])
    cout << Si;
  cout << endl;
  return 0;
}
