// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  int i, N;
  cin >> N;
  i = 2;
  while (i <= N) { // O(N) algorithm
    cout << i << " Abracadabra" << endl;
    i++;
  }
  // Note: using for-loop also can; and probably better for this problem
  // for (i = 1; i <= N; i++) // O(N)
  //   cout << i << " Abracadabra" << endl;
  return 0;
}
