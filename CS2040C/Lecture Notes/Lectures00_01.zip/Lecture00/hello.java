// import java.util.*; // no need to import anything as class System is available by default

class hello { // for Kattis problems, maybe we just give class name = Kattis problem id
  public static void main(String[] args) {
    System.out.println("Hello World!"); // O(1) algorithm
    // System.out.print("Hello World!\n"); // also can
    // System.out.printf("Hello World!\n"); // also can (we may use printf for certain output formatting needs)
    // Kattis is quite forgiving with white spaces so putting \n at the end or not does not 'matter' (but other online judge like Mooshak will be more strict)
  }
}
