// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.io.*;

class treasurehunt {
  static char[][] grid = new char[210][210]; // global variable to simplify this code
  static PrintWriter pw;

  static void go(int row, int col, int step, int NumR, int NumC) {
    if (row < 0 || row >= NumR || col < 0 || col >= NumC)
      pw.printf("0ut\n");
    else if (step > NumR*NumC)
      pw.printf("Lost\n");
    else if (grid[row][col] == 'T')
      pw.printf("%d\n", step);
    else if (grid[row][col] == 'N')
      go(row-1, col  , step+1, NumR, NumC);
    else if (grid[row][col] == 'E')
      go(row  , col+1, step+1, NumR, NumC);
    else if (grid[row][col] == 'S')
      go(row+1, col  , step+1, NumR, NumC);
    else if (grid[row][col] == 'W')
      go(row  , col-1, step+1, NumR, NumC);
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    pw = new PrintWriter(System.out);
    int R, C;
    String[] token = br.readLine().split(" ");
    R = Integer.parseInt(token[0]);
    C = Integer.parseInt(token[1]);
    for (int i = 0; i < R; i++)
      grid[i] = br.readLine().toCharArray();
    // // debug for a while
    // for (int i = 0; i < R; i++)
    //   pw.printf("row %d is '%s'\n", i+1, grid[i]);
    go(0, 0, 0, R, C);
    pw.close();
  }
}
