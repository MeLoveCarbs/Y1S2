#include <bits/stdc++.h> // let's just use this freebie template (line 1-4 and last two lines) for almost all our C++ code
using namespace std;

int main() {
  printf("Hello World!\n"); // O(1) algorithm
  // cout << "Hello World!\n"; // also can
  // cout << "Hello World!" << endl; // also can
  // Kattis is quite forgiving with white spaces so putting \n at the end or not does not 'matter' (but other online judge like Mooshak will be more strict)
  return 0;
}
