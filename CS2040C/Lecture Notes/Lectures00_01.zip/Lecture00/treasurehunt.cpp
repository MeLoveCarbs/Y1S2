// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

char grid[210][210];

void go(int row, int col, int step, int NumR, int NumC) {
  if (row < 0 || row >= NumR || col < 0 || col >= NumC)
    printf("0ut\n");
  else if (step > NumR*NumC)
    printf("Lost\n");
  else if (grid[row][col] == 'T')
    printf("%d\n", step);
  else if (grid[row][col] == 'N')
    go(row-1, col  , step+1, NumR, NumC);
  else if (grid[row][col] == 'E')
    go(row  , col+1, step+1, NumR, NumC);
  else if (grid[row][col] == 'S')
    go(row+1, col  , step+1, NumR, NumC);
  else if (grid[row][col] == 'W')
    go(row  , col-1, step+1, NumR, NumC);
}

int main() {
  // freopen("in.txt", "r", stdin);
  int R, C;
  scanf("%d %d ", &R, &C);
  for (int i = 0; i < R; i++)
    scanf("%s ", &grid[i]);
  // // debug for a while
  // for (i = 0; i < R; i++)
  //   printf("row %d is '%s'\n", i+1, grid[i]);
  go(0, 0, 0, R, C);
  return 0;
}
