// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.io.*; // now we need to import this to use Buffered I/O instead of java.util.* (for Scanner)

class timeloop {
  public static void main(String[] args) throws Exception { // I/O methods may generate exception, we know that our inputs are nicely formatted so we will choose to ignore those Exceptions
    int i, N;
    // Scanner sc = new Scanner(System.in); // this is one of the most flexible input method but not the fastest
    // N = sc.nextInt();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // Buffered Input is faster
    N = Integer.parseInt(br.readLine()); // but more complicated to read
    i = 2;
    PrintWriter pw = new PrintWriter(System.out); // BufferedOutput is faster
    while (i <= N) { // O(N) algorithm
      // System.out.printf("%d Abracadabra\n", i); // printf is more flexible but actually slightly slower than print or println
      pw.printf("%d Abracadabra\n", i); // fortunately it has printf method too
      i++;
    }
    // Note: using for-loop also can; and probably better for this problem
    // for (i = 1; i <= N; i++) // O(N)
    //   System.out.println(i + " Abracadabra"); // yet another example of different output method
    //   pw.println(i + " Abracadabra"); // faster
    pw.close(); // do not forget to close the buffer and actually print the output to stdout
  }
}
