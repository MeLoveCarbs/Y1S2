// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  int l, r;
  scanf("%d %d", &l, &r);
  // O(1) algorithm
       if (l+r == 0) printf("Not a moose\n");
  else if (l == r)   printf("Even %d\n", l+r);
  else               printf("Odd %d\n", 3*max(l, r)); // check C++ STL algorithm reference for the explanation about built-in function max: http://en.cppreference.com/w/cpp/algorithm/max
  return 0;
}
