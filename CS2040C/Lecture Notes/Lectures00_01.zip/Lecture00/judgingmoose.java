// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.util.*; // we need java.util for Scanner class (there are other ways to read input)

class judgingmoose {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in); // this is one of the most flexible input method but not the fastest
    int l, r;
    l = sc.nextInt();
    r = sc.nextInt();
    // O(1) algorithm
         if (l+r == 0) System.out.println("Not a moose"); // notice that I purposely use 3 print styles in the same code for demonstration
    else if (l == r)   System.out.print("Even " + (l+r) + "\n");
    else               System.out.printf("Odd %d\n", 3*Math.max(l, r)); // check Java API reference for the explanation about built-in function max: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#max-int-int-
  }
}
