// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

// this piece of code is called twice, so it is better to modularise it as a function
int value(int d1, int d2) { // O(1)
  if ((d1 == 1 && d2 == 2) || (d1 == 2 && d2 == 1)) return 1000; // highest, higher than 66 = 600 below
  if (d1 == d2) return d1*100; // 66 = 600, 55 = 500, ..., 11 = 100
  if (d1 > d2) return d1*10+d2;
  else         return d2*10+d1;
}

int main() {
  int s0, s1, r0, r1, v1, v2;
  // let T be the number of test cases/lines in the problem
  // so the entire program is O(T * 1) = O(T)
  while (scanf("%d %d %d %d", &s0, &s1, &r0, &r1), (s0 || s1 || r0 || r1)) {
    // the next 5 lines are all O(1)
    v1 = value(s0, s1);
    v2 = value(r0, r1); // as we are going to compute the same thing twice, we better use a function here
         if (v1 > v2) printf("Player 1 wins.\n");
    else if (v1 < v2) printf("Player 2 wins.\n");
    else              printf("TieS.\n");
  }
  return 0;
}
