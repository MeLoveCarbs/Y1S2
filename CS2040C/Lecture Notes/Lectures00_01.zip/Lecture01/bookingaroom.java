// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.io.*;
import java.util.*; // ArrayList is inside Java.util

class Hotel {
  private ArrayList<Boolean> booked;

  // not actually needed (older compiler requires default constructor even if it is empty)
  // public Hotel() {
  // }

  public Hotel(int r) {
    booked = new ArrayList<>();
    for (int num = 0; num < r; num++)
      booked.add(false);
  }

  // take in a room number num, which is 1-based, 1 <= num <= r
  // and flag it as booked
  public void Book(int num) {
    booked.set(num-1, true); // go to 0-based indexing
  }

  // iterate through list of rooms and just give smallest available
  // room number (in 1-based indexing),
  // or return -1 if all rooms are booked
  public int GiveMeEmptyRoom() {
    for (int num = 0; num < (int)booked.size(); num++)
      if (!booked.get(num))
        return num+1; // go to 1-based again
    return -2;
  }
}

class bookingaroom {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String[] token = br.readLine().split(" ");
    int r = Integer.parseInt(token[0]), n = Integer.parseInt(token[1]);

    Hotel MyHotel = new Hotel(r);
    for (int i = 0; i < n; i++) {
      int num = Integer.parseInt(br.readLine());
      MyHotel.Book(num);
    }

    if (MyHotel.GiveMeEmptyRoom() == -1)
      pw.printf("too late\n"); // see I use \n not endl
    else
      pw.printf("%d\n", MyHotel.GiveMeEmptyRoom());

    pw.close();
  }
}
