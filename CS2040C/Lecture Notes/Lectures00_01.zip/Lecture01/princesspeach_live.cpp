// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h> // to include every library, not recommended to use this in real SE projects
using namespace std; // not recommended to use this in real SE projects

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL); // to make cin/cout faster
  int N, Y; cin >> N >> Y; // notice my style of declaring variables (and their types) and then reading them in one line..., you can separate this to multiple lines if you want
  bool found[110]; memset(found, false, sizeof found); // we just need a Boolean array of size at most 100 (as 0 < N <= 100) in the problem, so the obstacles range from [0..99] AT MOST, I just like to over declare array size by a bit (+10 usually). memset is a C style function to 'fill' the array with a specific value (all false)
  // bool found[110] = { false }; // also works, which probably easier for most people :O
  for (int i = 0; i < Y; i++) { // the Y obstacles that Mario said he found... 0 <= Y <= 200, notice Y <= 200, i.e. can be more than largest N, i.e. there CAN BE DUPLICATES
    int k; cin >> k; // k does not necessarily given in increasing order and not necessarily distinct
    found[k] = true; // it is possible that the same k is "found" multiple times by Mario, but it is ok, we will ever convert a false -> a true once and never the other direction
  }
  int X = 0; // X = number of distinct obstacles that Mario found
  for (int i = 1; i < N; i++) // this loop is as asked in the problem output
    if (!found[i])
      cout << i << endl;
    else
      X++;
  cout << "Mario got " << X << " of the dangerous obstacles.\n"; // using '\n' or endl is up to you, Kattis somewhat ignores this btw...
  return 0;
}
