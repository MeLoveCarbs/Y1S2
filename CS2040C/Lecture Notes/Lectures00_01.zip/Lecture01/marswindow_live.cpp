// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h> // to include every library, not recommended to use this in real SE projects
using namespace std; // not recommended to use this in real SE projects

int main() {
  // ios::sync_with_stdio(false); cin.tie(NULL); // to make cin/cout faster, not needed if we use scanf/printf
  int y; scanf("%d", &y);
  int cur_m = 3, cur_y = 2018; // I use 0-based indexing for cur_m, that ranges from [0 (January), 1 (February), ..., 11 (December)]
  while (cur_y < y) {
    cur_y += 2, cur_m += 3; // 26 months = 2 years+2 months
    if (cur_m >= 12) // overshot
      cur_y++, cur_m %= 12; // transfer the excess (cur_m/12 will be exactly 1, not more than that) to cur_y, reduce cur_m to be within [0..11] again
  }
  printf((cur_y == y) ? "yes\n" : "no\n"); // if cur_y stops at y, then y is a(nother) Mars launch window, otherwise we overshoot, so y is NOT a Mars launch window
  return 0;
}

// Final challenge, there is actually a DIRECT formula to solve this problem without using simulated loop like above, do you know how to get that?
