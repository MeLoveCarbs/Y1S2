// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

// see much more detailed comment in the polished statistics.cpp/java

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int n, caseNo = 1;
  while (cin >> n) {
    int minV = 1e1, maxV = -1e9;
    for (int i = 0; i < n; i++) {
      int v; cin >> v;
      minV = min(minV, v);
      maxV = max(maxV, v);
    }
    cout << "Case " << caseNo++ << ": " << minV << " " << maxV << " " << (maxV-minV) << endl;
  }
  return 0;
}
