// there is 1 character bug in this code, submitting it verbatim will be WA

#include <bits/stdc++.h>
using namespace std;

unordered_map<string, vector<string>> AL;
unordered_map<string, int> visited;
bool back_edge_exist;

void debug() {
    for (auto &city_neighbors : AL) {
        string city = city_neighbors.first;
        cout << "city " << city << ":";
        for (auto &n : city_neighbors.second)
            cout << " " << n;
        cout << endl;
    }
    for (auto &city_visited : visited) {
        cout << "city " << city_visited.first << " visited? " << city_visited.second << endl;
    }
}

void dfs(string u) {
    //cout << "mom at city " << u << endl;
    visited[u] = 1; // explored (but not fully done)
    for (auto &v : AL[u]) {
        if (visited.find(v) == visited.end())
            dfs(v);
        else if (visited[v] == 1)
            back_edge_exist = true;
    }
    visited[u] = 1; // done
}

int main() {
    //freopen("in.txt", "r", stdin);
    ios::sync_with_stdio(false); cin.tie(NULL);
    int n; cin >> n; cin.get();
    for (int i = 0; i < n; ++i) {
        string o, d; cin >> o >> d; cin.get();
        AL[o].push_back(d); // directed
    }
    //debug();
    while (1) {
        string s; cin >> s; cin.get();
        if (cin.eof()) break;
        back_edge_exist = false;
        visited.clear();
        dfs(s);
        cout << s << (back_edge_exist ? " safe" : " trapped") << endl;
    }
    return 0;
}
