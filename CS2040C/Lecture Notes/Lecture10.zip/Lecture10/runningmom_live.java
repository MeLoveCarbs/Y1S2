// there is 1 character bug in this code, submitting it verbatim will be WA

import java.io.*;
import java.util.*;

class runningmom_live {
  static HashMap<String, HashSet<String>> AL = new HashMap<>();
  // static HashSet<String> visited;
  static HashMap<String, Integer> visited_status;
  static Boolean can_find_cycle;

  static void dfs(String u) {
    // THERE IS ONE SILLY BUG THAT COSTS US 10 SOMETHING AWKWARD MINUTES... IT IS SOMEWHERE IN THIS DFS METHOD
    // IF YOU UNDERSTAND WHAT TO FIX, YOU CAN GET AC AGAIN
    visited_status.put(u, 1); // 1 means VISITED but not yet fully explored
    if (can_find_cycle) return;
    if (AL.get(u) == null) return;
    for (String v : AL.get(u)) {
      if (visited_status.get(v) == 0)
        dfs(v); // u->v is a tree edge, part of DFS spanning tree, OK
      else if (visited_status.get(v) == 1)
        can_find_cycle = true; // u->v is blue to blue -> cycle?
    }
    visited_status.put(u, 1); // 2 means FULLY VISITED (all neighbors explored)
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int n = Integer.parseInt(br.readLine()); // n is actually E (number of edges)
    HashSet<String> allcities = new HashSet<>();
    while (n-- > 0) {
      String[] token = br.readLine().split(" ");
      String u = token[0], v = token[1]; // edge u->v (in StringS)
      if (AL.get(u) == null)
        AL.put(u, new HashSet<String>());
      AL.get(u).add(v); // add edge u->v
      allcities.add(u);
      allcities.add(v);
    }

    // pw.println(AL);
    while (true) {
      String source = br.readLine();
      if (source == null) break;

      can_find_cycle = false;
      visited_status = new HashMap<>();
      for (String u : allcities)
        visited_status.put(u, 0); // 0 means unvisited
      dfs(source);
      pw.println(source + (can_find_cycle ? " safe" : " trapped"));
    }
 
    pw.close();
  }
}
