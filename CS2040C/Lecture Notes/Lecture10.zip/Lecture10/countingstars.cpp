// there is 1 character bug in this code, submitting it verbatim will be WA

#include <bits/stdc++.h>
using namespace std;

#define MAX_RC 110

int R, C;
int dr[] = { 0, 1, 0,-1}; // E/S/W/N
int dc[] = {-1, 0,-1, 0};
char grid[MAX_RC][MAX_RC];

void floodFill(int r, int c) {
  if (r < 0 || r >= R || c < 0 || c >= C || grid[r][c] == '#') return;
  grid[r][c] = '#';
  for (int d = 0; d < 4; d++) floodFill(r+dr[d], c+dc[d]);
}

int main() {
  int caseNo = 1;
  while (scanf("%d %d ", &R, &C) != EOF) {
    for (int i = 0; i < R; i++) scanf("%s ", &grid[i]);
    int ans = 0;
    for (int i = 0; i < R; i++)
      for (int j = 0; j < C; j++)
        if (grid[i][j] == '-') {
          ans++;
          floodFill(i, j);
        }
    printf("Case %d: %d\n", caseNo++, ans);
  }
  return 0;
}
