// there is 1 character bug in this code, submitting it verbatim will be WA

import java.io.*;
import java.util.*;

class countingstars_live {
  static int m, n;
  static char[][] sky;
  static int[] dr = new int[]{ 0, 1, 0,-1}; // E/S/W/N
  static int[] dc = new int[]{-1, 0,-1, 0};

  static void floodfill(int r, int c, char origin, char target) {
    if (r < 0 || r >= m || c < 0 || c >= n) return; // outside the sky grid
    if (sky[r][c] != origin) return; // not a '-'...
    sky[r][c] = target;
    for (int d = 0; d < 4; d++) {
      int nr = r+dr[d], nc = c+dc[d];
      floodfill(nr, nc, origin, target);
    }
  }

  static void debug() {
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < n; j++)
        System.out.print(sky[i][j] + " ");
      System.out.println();
    }
    System.out.println();
    System.out.println();
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int caseNo = 1;
    while (true) {
      String R_C = br.readLine();
      if (R_C == null) break;
      String[] token = R_C.split(" ");
      m = Integer.parseInt(token[0]); n = Integer.parseInt(token[1]);

      sky = new char[m][n];
      for (int i = 0; i < m; i++) {
        sky[i] = br.readLine().toCharArray();
      }

      int ans = 0;
      for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
          if (sky[i][j] == '-') {
            ans++;
            floodfill(i, j, '-', (char)('0'+ans));
            debug(); // uncomment this before submission, otherwise WA
          }

      pw.printf("Case %d: %d\n", caseNo++, ans);
    }

    pw.close();
  }
}