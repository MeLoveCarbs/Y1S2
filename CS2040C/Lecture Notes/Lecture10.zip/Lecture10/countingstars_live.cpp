// there is 1 character bug in this code, submitting it verbatim will be WA

#include <bits/stdc++.h>
using namespace std;

int m, n;
int dr[] = { 0, 1, 0,-1}; // east/south/west/north
int dc[] = {-1, 0,-1, 0};
string grid[110];

void dfs_floodfill(int row, int col) {
    grid[row][col] = '#'; // erase the dash, make it '#' (sky)
    for (int d = 0; d < 4; ++d) {
        int new_row = row+dr[d], new_col = col+dc[d];
        if ((new_row < 0) || (new_col < 0) || (new_row >= m) || (new_col >= n)) // outside my m*n grid
            continue;
        if (grid[new_row][new_col] == '#') // don't go to a '#' (sky)
            continue;
        dfs_floodfill(new_row, new_col);
    }
}

int main() {
    //freopen("in.txt", "r", stdin);
    ios::sync_with_stdio(false); cin.tie(NULL);
    int caseNo = 0;
    while (1) {
        cin >> m >> n; cin.get();
        if (cin.eof()) break;
        for (int r = 0; r < m; ++r) {
            cin >> grid[r];
        }
        int ans = 0;
        for (int r = 0; r < m; ++r)
            for (int c = 0; c < n; ++c)
                if (grid[r][c] == '-') {
                    ++ans;
                    dfs_floodfill(r, c);
                }
        cout << "Case " << (++caseNo) << ": " << ans << endl;
    }
    return 0;
}
