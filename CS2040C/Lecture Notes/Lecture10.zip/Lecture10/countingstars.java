// there is 1 character bug in this code, submitting it verbatim will be WA

import java.io.*;
import java.util.*;

class countingstars {
  static final int MAX_RC = 110;
  static int R, C;
  static int[] dr = new int[]{ 0, 1, 0,-1}; // E/S/W/N
  static int[] dc = new int[]{-1, 0,-1, 0};
  static char[][] grid = new char[MAX_RC][MAX_RC];

  static void floodFill(int r, int c) {
    if (r < 0 || r >= R || c < 0 || c >= C || grid[r][c] == '#') return;
    grid[r][c] = '#';
    for (int d = 0; d < 4; d++) floodFill(r+dr[d], c+dc[d]);
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int caseNo = 1;
    while (true) {
      String R_C = br.readLine();
      if (R_C == null) break;
      String[] token = R_C.split(" ");
      R = Integer.parseInt(token[0]); C = Integer.parseInt(token[1]);
      for (int i = 0; i < R; i++) grid[i] = br.readLine().toCharArray();
      int ans = 0;
      for (int i = 0; i < R; i++)
        for (int j = 0; j < C; j++)
          if (grid[i][j] == '-') {
            ans++;
            floodFill(i, j);
          }
      pw.printf("Case %d: %d\n", caseNo++, ans);
    }

    pw.close();
  }
}

