#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;

// global variables
vi visited;
vector<vii> RevG;
int ans;

void dfs(int u) {
  visited[u] = 1;
  for (auto &[v, w] : RevG[u]) {
    ans += w; // put this ans += w; OUTSIDE the !visited[v] check below
    if (!visited[v]) {
      dfs(v);
    }
  }
}

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  freopen("in_flowerytrails.txt", "r", stdin);

  int P, T; cin >> P >> T;
  vector<vii> AL(P, vii());
  RevG.assign(P, vii()); // the reversed graph :O, initially empty
  while (T--) {
    int p1, p2, l; cin >> p1 >> p2 >> l;
    AL[p1].push_back(make_pair(p2, l)); // showing push_back
    AL[p2].emplace_back(p1, l); // bidirectional, showing emplace_back
  }

  int s = 0; // entrance is always vertex 0 in this problem
  vi dist(P, INF);
  dist[s] = 0;
  priority_queue<ii, vector<ii>, greater<ii>> pq;
  pq.push({dist[s], s});
  while (!pq.empty()) {
    auto [d, u] = pq.top(); pq.pop();
    if (u == P-1) break; // to ensure that we do not add unnecessary edges that will not be taken by the "common people" (those who only use shortest path)
    if (d > dist[u]) continue; // inferior (d, u) pair that is deleted now
    for (auto &[v, w] : AL[u]) {
      if (dist[u]+w < dist[v]) {
        dist[v] = dist[u]+w;
        pq.push({dist[v], v}); // we enqueue better (dist[v], v), leaving (old-dist[v], v) lazily inside the min pq
        RevG[v].clear(); // erase all (if any), will be beaten by this edge
        RevG[v].emplace_back(u, w); // add edge v->u with weight w in the reverse graph :O
      }
      else if (dist[u]+w == dist[v]) {
        RevG[v].emplace_back(u, w); // append edge v->u with weight w that will lead to different, but equally short SHORTEST PATH from s to P-1
      }
    }
  }

  // // if you want to see the content of the reversed graph, uncomment this line
  // for (int u = 0; u < P; ++u)
  //   for (auto &[v, w] : RevG[u]) {
  //     cout << " edge " << u << " -> " << v << ", weight " << w << endl;
  //   }

  visited.assign(P, 0);
  ans = 0;
  dfs(P-1); // explore the reverse graph from peak (vertex P-1) and sum all edge weights seen there
  cout << 2*ans << endl; // multiply the answer by 2 (left and right side of the trail)

  return 0;
}
