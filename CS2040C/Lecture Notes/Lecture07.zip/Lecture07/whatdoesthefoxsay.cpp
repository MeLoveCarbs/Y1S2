// What does the fox says?
// put set of excluded sounds in a (very fast) Table ADT

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL); // better use this for all cin/cout stuffs
  int T;
  cin >> T; cin.get(); // to immediately consume next line '\n' symbol after variable T, if you forget to do this, you will have confusing wrong getline(cin, line) in line 13 below
  while (T--) {
    string line;
    getline(cin, line); // get the line that contain recording of animal sounds, save it first, we will tokenize it later below
    unordered_set<string> not_fox; // ah, we need ability to hash an animal sound that is not fox into a (very fast) Table ADT
    while (1) { // let A be the number of animals, line 17-24 will be repeated A times before we stop
      string animal_goes_sound, sound;
      getline(cin, animal_goes_sound);
      if (animal_goes_sound == "what does the fox say?") break; // end of input block
      istringstream iss1(animal_goes_sound);
      iss1 >> sound; // the name of animal (no need to record)
      iss1 >> sound; // the word 'goes', no need to do anything
      iss1 >> sound; // ah, this is the sound of that not-fox animal
      not_fox.insert(sound); // just record this not-fox sound, in O(M) = ~O(1) time, to our hash table (unordered_set<string>), 
                             // O(1) if you don't care about length of string
                             // however, if you want to be very specific, hashing a string of M characters need O(M), M = 100 in this problem
    }
    istringstream iss2(line);
    string sound;
    while (iss2 >> sound) { // let T be the number of words/sounds heard in the forest, line 31-32 will be repeated T times
    // while (getline(iss2, sound, ' ')) { // the delimiter is white space in this problem, so we do not need to use this form and just do iss2 >> sound as above
      if (not_fox.find(sound) != not_fox.end()) continue; // skip this sound, not fox's sound, here, each check is that O(M) =~ O(1)!!!
      cout << sound << " "; // Kattis forgives extra " " at the back (we can do a bit extra work to fix this though)
    }
    cout << endl;
  }
  // the overall time complexity of the code above is O(T*(A+W)*M)
  return 0;
}
