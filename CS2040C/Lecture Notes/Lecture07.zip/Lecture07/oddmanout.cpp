#include <bits/stdc++.h>
using namespace std;

int main() {
  int caseNo = 1, N;
  cin >> N; // there are N test cases
  while (N--) { // while N is still positive, it means there is still at least one test case left, continue while loop and decrement N, 
                // when N is 0, we stop (no more test case)
    int G;
    cin >> G;
    // int f[2147483648LL] = {0}; // this one CMI
    // trying to create Direct Addressing Table of size 2^31 (I use LL just in case some compiler interpret it as signed 32-bit integer and overflows)
    // will cause Memory Limit Exceeded as 2147483648 cells*4 Bytes/cell = 8 GB of memory required (Memory Limit is 1 GB for this problem)
    unordered_map<int, int> f; // frequency table f, unordered_map is a hash table
    for (int i = 0; i < G; ++i) { // go through G times, this one is clearly O(G)
      int v;
      cin >> v; // v is the invitation code of this guest, O(1)
      ++f[v]; // ah, this is probably new for most of you, if v is not in hash table f before, then f[v] == 0 and ++f[v] will make it 1
              // if v is already in hash table f, then ++f[v] will increment the previous value of f[v] by 1
              // for this problem, the final values of f[v] for all v is mostly 2, except for 1 single odd man
              // hash table operations are advertised O(1)
    }
    int ans = 0;
    // C++11 style, use this for PE if our lab computers cannot handle C++17 standard yet (commented below)
    for (auto &key_value : f) // map stores information in (key, value) pairs, we iterate through all such (key, value) pairs
      if (key_value.second == 1) // trying to find the only one key (invitation code) with value (frequency) 1
        ans = key_value.first; // save that answer (we can also break here)
    // for (auto &[key, value] : f) // C++17 way, structured bindings
    //   if (value == 1)
    //     ans = key;
    cout << "Case #" << caseNo++ << ": " << ans << endl; // print as required
  }
  // overall, we have O(G) in line 15-21, O((G-1)/2) = O(G) also in line 22-24, and we repeat line 8-25 N times, so overall this is an O(N*G) solution
  return 0;
}

// PS1: naive O(N*G^2) solution can still pass the Time Limit @ Kattis as G is just 1000, but you realize that we will not give you small input in PE, right??
// PS2: there is another O(N*G log G) solution involving sorting, do you realize that?
