import java.io.*;
import java.util.*;

class oddmanout {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int caseNo = 1;
    int N = Integer.parseInt(br.readLine()); // there are N test cases
    while (N-- > 0) { // while N is still positive, it means there is still at least one test case left, continue while loop and decrement N, 
                      // when N is 0, we stop (no more test case)
      int G = Integer.parseInt(br.readLine());
      // int[] f = new int[2147483648LL]; // this one CMI
      // trying to create Direct Addressing Table of size 2^31 (I use LL just in case some compiler interpret it as signed 32-bit integer and overflows)
      // will cause Memory Limit Exceeded as 2147483648 cells*4 Bytes/cell = 8 GB of memory required (Memory Limit is 1 GB for this problem)
      HashMap<Integer, Integer> f = new HashMap<Integer, Integer>(); // frequency table f, HashMap is a hash table
      String[] token = br.readLine().split(" ");
      for (int i = 0; i < G; i++) { // go through G times, this one is clearly O(G)
        int v = Integer.parseInt(token[i]); // v is the invitation code of this guest, O(1)
        // for this problem, the final values of f.get(v) for all v is mostly 2, except for 1 single odd man
        if (f.get(v) == null)
          f.put(v, 1);
        else
          f.put(v, f.get(v)+1);
        // hash table operations are advertised O(1)
      }

      int ans = 0;
      for (Map.Entry<Integer, Integer> pair : f.entrySet()) // map stores information in (key, value) pairs, we iterate through all such (key, value) pairs
        if (pair.getValue() == 1) // trying to find the only one key (invitation code) with value (frequency) 1
          ans = pair.getKey(); // save that answer (we can also break here)

      pw.printf("Case #%d: %d\n", caseNo++, ans); // print as required
    }
    // overall, we have O(G) in line 15-21, O((G-1)/2) = O(G) also in line 22-24, and we repeat line 8-25 N times, so overall this is an O(N*G) solution

    pw.close();
  }
}

// PS1: naive O(N*G^2) solution can still pass the Time Limit @ Kattis as G is just 1000, but you won't do it for our PE right?
// PS2: there is another O(N*G log G) solution involving sorting, do you realize that?
