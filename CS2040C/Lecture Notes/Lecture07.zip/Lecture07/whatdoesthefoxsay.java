// What does the fox says?
// put set of excluded sounds in a (very fast) Table ADT

import java.io.*;
import java.util.*;

class whatdoesthefoxsay {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int T = Integer.parseInt(br.readLine());
    while (T-- > 0) {
      String line = br.readLine(); // get the line that contain recording of animal sounds, save it first
      HashSet<String> not_fox = new HashSet<String>(); // ah, we need ability to hash an animal sound that is not fox into a (very fast) Table ADT
      while (true) { // let A be the number of animals, line 17-24 will be repeated A times before we stop
        String animal_goes_sound = br.readLine();
        if (animal_goes_sound.equals("what does the fox say?")) break; // end of input block
        String[] token = animal_goes_sound.split(" ");
        // first token is the name of animal (no need to record)
        // second token is the word 'goes', no need to do anything
        // third token is the sound of that not-fox animal
        not_fox.add(token[2]); // just record this not-fox sound, in O(M) = ~O(1) time, to our hash table (unordered_set<string>), 
                               // O(1) if you don't care about length of string
                               // however, if you want to be very specific, hashing a string of M characters need O(M), M = 100 in this problem
      }
      String[] token = line.split(" ");
      for (int i = 0; i < token.length; i++) { // let T be the number of words/sounds heard in the forest, line 29-30 will be repeated T times
        if (not_fox.contains(token[i])) continue; // skip this sound, not fox's sound, here, each check is that O(M) =~ O(1)!!!
        pw.print(token[i] + " "); // Kattis forgives extra " " at the back (we can do a bit extra work to fix this though)
      }
      pw.println();
    }

    pw.close();
  }
}
