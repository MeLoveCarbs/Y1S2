// there is a one character typo in this code, submitting it verbatim will give you WA :O

import java.io.*;
import java.util.*;

class baconeggsandspam {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    while (true) {
      int n = Integer.parseInt(br.readLine()); // read n
      if (n == 0) break; // stop if n is 0
      TreeMap<String, TreeSet<String>> magic_ds = new TreeMap<>(); // YES, you can do that!!, you can map a (simple) data type to a (complex) data type
      for (int i = 0; i <= n; i++) { // O(n * k * m * log n)
        String[] token = br.readLine().split(" ");
        String name = token[0]; // name of the customer
        for (int j = 1; j < token.length; j++) { // k = at most 10 orders per individual, so somewhat constant but affects the overall runtime by 10 times slower, O(k * m * log n)
          if (magic_ds.get(token[j]) == null) { // token[j] = food item
            TreeSet<String> person = new TreeSet<>();
            person.add(name);
            magic_ds.put(token[j], person);
          }
          else
            magic_ds.get(token[j]).add(name); // O(m * log n), m = at most 15 characters, this also somewhat affects runtime per insertion
          // pw.printf("%s orders %s\n", name, token[j]);
        }
      }
      for (Map.Entry<String, TreeSet<String>> pair : magic_ds.entrySet()) { // O(n * k *m items will be printed at most)
        pw.print(pair.getKey());
        for (String diner : pair.getValue()) // auto sorting here :)
          pw.print(" " + diner);
        pw.println();
      }
      pw.println();
    } // TC = about 100, so O(TC * n * k * m * log n)

    pw.close();
  }
}
