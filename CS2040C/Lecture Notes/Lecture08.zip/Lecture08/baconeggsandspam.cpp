// Bacon Eggs and Spam
// there is a one character typo in this code, submitting it verbatim will give you WA :O

#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  while (cin >> n, n) { // read n and see if it is 0? (stop if it is)
    cin.get(); // consume new line after n
    map<string, set<string>> magic_ds; // YES, you can do that!!, you can map a (simple) data type to a (complex) data type (or vice versa, to be demo-ed later)
    for (int i = 0; i <= n; ++i) { // O(n * k * m * log n)
      string line, name, order;
      getline(cin, line);
      istringstream iss(line); // I hope that nobody has problem with String Tokenization anymore...
      iss >> name; // first token is the name of customer
      while (iss >> order) { // k = at most 10 orders per individual, so somewhat constant but affects the overall runtime by 10 times slower, O(k * m * log n)
        magic_ds[order].insert(name); // O(m * log n), m = at most 15 characters, this also somewhat affects runtime per insertion
        // cout << name << " orders " << order << endl;
      }
    }
    // for (auto &[item, setofnames] : magic_ds) { // C++17 style, won't work in older compiler
    //   cout << item;
    //   for (auto &name : setofnames) // auto sorting here :)
    //     cout << " " << name;
    //   cout << endl;
    // }
    for (auto &item_setofnames : magic_ds) { // O(n * k * m) items will be printed at most
      cout << item_setofnames.first;
      for (auto &name : item_setofnames.second) // auto sorting here :)
        cout << " " << name;
      cout << endl;
    }
    cout << endl;
  } // TC = about 100, so O(TC * n * k * m * log n)
  return 0;
}
