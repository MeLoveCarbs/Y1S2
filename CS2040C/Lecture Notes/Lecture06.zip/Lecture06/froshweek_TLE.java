// Frosh Week
// the TLE version

import java.io.*;
import java.util.*;

class froshweek_TLE {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int n = Integer.parseInt(br.readLine());
    int[] a = new int[n];
    for (int i = 0; i < n; i++) // O(n)
      a[i] = Integer.parseInt(br.readLine());

  // the meat: given an array a, count # of Bubble Sort swaps... but without using O(n^2) Bubble Sort (too slow)

    // TLE...
    long ans = 0; // int is WA :O... do you realize why?
    Boolean is_swapped = false;
    do { // overall O(n^2), TLE... n is up to 1M (MILLION :O:O)
      is_swapped = false;
      for (int j = 0; j < n-1; j++) // O(n)
        if (a[j] > a[j+1]) { // if not sorted
          is_swapped = true;
          ans++; // swap them
          int temp = a[j];
          a[j] = a[j+1];
          a[j+1] = temp;
        }
    }
    while (is_swapped); 

    // hint:...
    // mergeSort(a, 0, n-1);

    pw.println(ans);
    pw.close();
  }
}
