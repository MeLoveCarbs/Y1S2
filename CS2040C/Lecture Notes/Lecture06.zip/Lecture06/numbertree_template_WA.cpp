// submitting this code verbatim will give you WA

#include <bits/stdc++.h>
using namespace std;

int left(int i) { return i<<1; } // 2*i

int right(int i) { return (i<<1)+1; } // (2*i)+1

int main() {
  int H;
  string path;
  cin >> H >> path;
  int idx = 1;
  for (auto &cmd : path) {
    idx = (cmd == 'L') ? left(idx) : right(idx); // like complete binary tree traversal as shown for Binary Heap
    // PS: if the ternary operation above is too cryptic for you, the line above is equivalent to
    // if (cmd == 'L') {
    //   idx = left(idx);
    // }
    // else { // if (cmd == 'R') {
    //   idx = right(idx);
    // }
  }
  cout << idx << endl; // this is not what the required final answer... in class we have discussed how to get the final answer
  return 0;
}
