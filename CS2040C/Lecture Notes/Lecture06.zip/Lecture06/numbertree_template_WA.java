// submitting this code verbatim will give you WA

import java.io.*;

class numbertree_template_WA {
  private static int left(int i) { return i<<1; } // 2*i

  private static int right(int i) { return (i<<1)+1; } // (2*i)+1

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String[] token = br.readLine().split(" ");
    int H = Integer.parseInt(token[0]);
    int idx = 1;
    if (token.length > 1) {
      char[] path = token[1].toCharArray();
      for (char cmd : path) {
        idx = (cmd == 'L') ? left(idx) : right(idx); // like complete binary tree traversal as shown for Binary Heap
        // PS: if the ternary operation above is too cryptic for you, the line above is equivalent to
        // if (cmd == 'L') {
        //   idx = left(idx);
        // }
        // else { // if (cmd == 'R') {
        //   idx = right(idx);
        // }
      }
    }
    pw.println(idx); // this is not what the required final answer... in class we have discussed how to get the final answer

    pw.close();
  }
}
