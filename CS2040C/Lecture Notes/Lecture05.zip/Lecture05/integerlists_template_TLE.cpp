// Integer Lists
// submitting this code verbatim clearly TLE (and please do not do so, no point submitting my clearly AC demo code to Kattis just to get Kattis points... you will learn more by adapting your own code until AC or writing your own version from scratch until AC)
// we have discussed the reasons in class and Steven has shown his AC code

#include <bits/stdc++.h>
using namespace std;

int main() {
  // freopen("in_integerlists.txt", "r", stdin); // a technique to redirect input from file to our stdin, so that we do not have to type in long (sample/additional) test cases when testing our code, the in.txt that contains sample input is also provided in this zip file

  int TC;
  scanf("%d ", &TC); // consume '\n' (newline) character
  while (TC--) {
    char p[100010]; // enlarge a bit just in case, max p in the problem is 100K characters
    int n;
    scanf("%s ", &p);
    scanf("%d ", &n);
    scanf("["); // a potentially new scanf technique, consume '[' character, if you are a pure C++ coder, you can use cin.get()
    vector<int> x; // something is SLOW because of this... try forward_list, list, deque?
    for (int i = 0; i < n; i++) {
      if (i) {
        scanf(","); // consume those commas in between x_val(ues)
      }
      int x_val;
      scanf("%d", &x_val);
      x.push_back(x_val);
    }
    scanf("] "); // lastly, consume ']' and '\n' (newline) characters

    bool error = false;
    for (int i = 0; p[i]; i++) { // go through all commands, we cannot shorten this
      if (p[i] == 'R') {
        reverse(x.begin(), x.end()); // call std::reverse in C++ STL <algorithm>, analyze if this is a 'fast' operation or not (discussed again in tut03.pdf)
      }
      else { // a 'D'
        if (x.empty()) {
          error = true;
          break;
        }
        x.erase(x.begin()); // remove the front most element, analyze if this is a 'fast' operation or not (already discussed many times in class)
      }
    }

    if (!error) {
      printf("[");
      int i = 0;
      for (auto &v : x) {
        if (i) printf(",");
        i++;
        printf("%d", v);
      }
      printf("]\n");
    }
    else {
      printf("error\n");
    }
  }

  return 0;
}
