// there is a one character bug in this code, submitting it verbatim will cause wrong answer

import java.io.*;
import java.util.*; // Stack is here

class evenup {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int N = Integer.parseInt(br.readLine());
    Stack<Integer> s = new Stack<Integer>();
    String[] token = br.readLine().split(" ");
    for (int i = 0; i < N; i++) { // O(N), no other gimmicks
      int cur = Integer.parseInt(token[i]);
      if (!s.empty() && // super important check to avoid RTE
          ((s.peek()+cur)%3 == 0)) { // as discussed in class
        s.pop();
      }
      else {
        s.push(cur);
      }
    }
    pw.println(s.size());

    pw.close();
  }
}
