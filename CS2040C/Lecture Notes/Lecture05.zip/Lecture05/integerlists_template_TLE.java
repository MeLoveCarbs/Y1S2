import java.io.*;
import java.util.*; // ArrayList, LinkedList, and Deque are here

class integerlists_template_TLE {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int TC = Integer.parseInt(br.readLine());
    while (TC-- > 0) {
      char[] p = br.readLine().toCharArray(); // max p in the problem is 100K characters
      int n = Integer.parseInt(br.readLine());
      String line = br.readLine();
      line = line.substring(1, line.length()-1); // remove '[' in front and ']' at the back
      String[] token = line.split(","); // tokens are separated by ',' character

      ArrayList<Integer> x = new ArrayList<>(); // something is SLOW because of this... try LinkedList (or Deque)?
      for (int i = 0; i < n; i++) {
        x.add(Integer.parseInt(token[i])); // same as addLast
      }

      Boolean error = false;

      for (int i = 0; i < p.length; i++) { // go through all commands, we cannot shorten this
        if (p[i] == 'R') {

          Collections.reverse(x); // call Collections.reserve, analyze if this is a 'fast' operation or not (discussed again in tut03.pdf)
        }
        else { // a 'D'
          if (x.size() == 0) {
            error = true;
            break;
          }



          x.remove(0); // remove the front most element, analyze if this is a 'fast' operation or not (already discussed many times in class)
        }
      }

      if (!error) {


        pw.print("[");
        int i = 0;
        for (int v : x) {
          if (i > 0) pw.print(",");
          i++;
          pw.print(v);
        }
        pw.println("]");
      }
      else {
        pw.println("error");
      }
    }

    pw.close();
  }
}
