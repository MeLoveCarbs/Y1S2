// there is a one character bug in this code, submitting it verbatim will cause wrong answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  int N;
  cin >> N;
  stack<int> s;

  for (int i = 0; i < N; i++) { // O(N), no other gimmicks
    int cur;
    cin >> cur;
    if (!s.empty() && // super important check to avoid RTE
        ((s.top()+cur)%3 == 0)) { // as discussed in class
      s.pop();
    }
    else {
      s.push(cur);
    }
  }

  cout << (int)s.size() << endl; // I use (int) to safeguard against weird behavior involving size_type (the actual type returned by .size() method of std::stack)
  return 0;
}
