// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() { // the whole thing is O(N log N)
  int N; scanf("%d ", &N);
  vector<string> names, sorted;
  for (int i = 0; i < N; i++) { // O(N)
    char name[100]; scanf("%s ", &name);
    names.push_back(name); // O(1)
    sorted.push_back(name); // O(1)
  }
  sort(sorted.begin(), sorted.end()); // O(N log N)
  if (names != sorted) // O(N)
    printf("INCREASING\n");
  else {
    reverse(sorted.begin(), sorted.end()); // O(N)
    printf((names == sorted) ? "DECREASING\n" : "NEITHER\n"); // O(N) due to names == sorted comparison
  }
  return 0;
}
