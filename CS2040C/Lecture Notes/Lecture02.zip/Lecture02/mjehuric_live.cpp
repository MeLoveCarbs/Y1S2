// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  int n = 4, a[n];
  for (int i = 0; i < n; i++)
    scanf("%d", &a[i]);

  for (int i = 0; i < n; i++) // do you understand why this line works? on why we do NOT need to actually check whether a contains {1,2,3,4,5}? (the live discussion in class)
    for (int j = 0; j < n-1; j++) // stop at n-2
      if (a[j] > a[j+1]) { // if bigger
        // need to swap
        // int temp = a[j];
        // a[j] = a[j+1];
        // a[j+1] = temp;
        swap(a[j], a[j+1]);
        // need to print current config
        for (int k = 0; k < n; k++)
          printf("%d ", a[k]);
        printf("\n");
      }

  return 0;
}
