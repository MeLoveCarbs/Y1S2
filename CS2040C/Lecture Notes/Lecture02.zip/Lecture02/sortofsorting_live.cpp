// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  bool firstTC = true;
  while (true) {
    cin >> n;
    if (n == 0) break;
    vector<string> names(n); // new (2019) style, declare a vector with known required size n
    for (int i = 0; i < n; i++)
      cin >> names[i]; // then we can just cin like this, instead of using push_back
    stable_sort(names.begin(), names.end(), [](string a, string b) { // the magic is here
      if (a[0] != b[0])
        return a[0] < b[0];
      else
        return a[1] < b[1];
    });
    if (!firstTC) cout << endl;
    firstTC = false;
    for (int i = 0; i < n; i++)
      cout << names[i] << endl;
  }
  return 0;
}
