// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.io.*;
import java.util.*; // StringTokenizer is here

class autori {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String s = br.readLine(); // s has no whitespace
    StringTokenizer st = new StringTokenizer(s, "-"); // set character '-' as the delimiter
    while (st.hasMoreTokens()) // O(n) where n is the actual number of tokens in the input, n is very small...
      pw.printf("%s", st.nextToken().charAt(1)); // the the first (index 0) character of this token
    pw.printf("\n");
    pw.close();

    // other ways exist, e.g. String.split below or even just a simple for-loop
    // String[] tokens = sc.nextLine().split("-");
    // for (String token : tokens)
    //   System.out.print(token.charAt(0));
    // //System.out.println(); // optional
  }
}
