// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

// Zamka
#include <bits/stdc++.h>
using namespace std;

// as the_number is at most 5 digits, e.g. 10000
// then after at most 5 iterations, this function will stop and returns the ans
// so this is an O(5) ~=> O(1) function
int sum_of_digit(int the_number) { // there are other ways, this is just one of the way
  int digit_sum = 0;
  while (the_number) {
    digit_sum += the_number%10;
    the_number /= 100;
  }
  return digit_sum;
}

int main() {
  // freopen("in.txt", "r", stdin);
  // the whole thing below is O(D+D) = O(2D) ~=> O(D)
  // read L, D, X
  int L, D, X; cin >> L >> D >> X;
  // find min N, such that L <= N <= D, and sum_of_digit(N) == X
  for (int N = L; N <= D; N++) // O(D-L) iterations ~=> O(D-1) ~=> O(D)
    if (sum_of_digit(N) == X) { // O(1)
      cout << N << endl; // O(1)
      break;
    }
  // find max M, such that L <= M <= D, and sum_of_digit(M) == X
  for (int M = D; M >= L; M--)
    if (sum_of_digit(M) == X) {
      cout << M << endl;
      break;
    }
  return 0;
}
