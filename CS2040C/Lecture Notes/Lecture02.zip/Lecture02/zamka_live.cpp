// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

// see zamka.cpp for a polished version

#include <bits/stdc++.h>
using namespace std;

int sod(int v) {
  int ans = 0;
  while (v) {
    ans += v%10;
    v /= 100;
  }
  return ans;
}

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int L, D, X; cin >> L >> D >> X;
  for (int N = L; N <= D; N++)
    if (sod(N) == X) {
      cout << N << endl;
      break;
    }
  for (int M = D; M >= L; M--)
    if (sod(M) == X) {
      cout << M << endl;
      break;
    }
  return 0;
}
