// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

import java.io.*;

class zamka {
  // as the_number is at most 5 digits, e.g. 10000
  // then after at most 5 iterations, this function will stop and returns the ans
  // so this is an O(5) ~=> O(1) function
  static int sum_of_digit(int the_number) { // there are other ways, this is just one of the way
    int digit_sum = 0;
    while (the_number > 0) {
      digit_sum += the_number%10;
      the_number /= 100;
    }
    return digit_sum;
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    // the whole thing below is O(D+D) = O(2D) ~=> O(D)
    // read L, D, X
    int L = Integer.parseInt(br.readLine());
    int D = Integer.parseInt(br.readLine());
    int X = Integer.parseInt(br.readLine());

    // find min N, such that L <= N <= D, and sum_of_digit(N) == X
    int N;
    for (N = L; N <= D; N++) // O(D-L) iterations ~=> O(D-1) ~=> O(D)
      if (sum_of_digit(N) == X) { // O(1)
        pw.printf("%d\n", N); // O(1)
        break;
      }

    // find max M, such that L <= M <= D, and sum_of_digit(M) == X
    int M;
    for (M = D; M >= L; M--)
      if (sum_of_digit(M) == X) {
        pw.printf("%d\n", M); // O(1)
        break;
      }

    pw.close();
  }
}
