#include <bits/stdc++.h> // to include everthing
using namespace std; // dangerous

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  //char s[110]; scanf("%s", &s);
  //printf("%s\n", s);
  string s; cin >> s;
  stringstream ss(s); // in live demo, I use the general C++ stringstream, but in more detailed autori.cpp, I use istringstream (input stringstream), google for the differences, either one can be used
  string token; 
     
  // Tokenizing w.r.t. hyphen '-' 
  while (getline(ss, token, '-')) 
  { 
    cout << token[0];
  } 

  return 0;
}
