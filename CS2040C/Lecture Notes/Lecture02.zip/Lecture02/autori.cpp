// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h>
using namespace std;

int main() {
  string s; cin >> s; // it works because s has no whitespace, so a single cin >> s gets the entire input
  string token;
  istringstream iss(s); // study istringstream+getline documentation for the details
  while (getline(iss, token, '-')) // O(n) where n is the actual number of tokens in the input, n is very small...
    cout << token[1];
  cout << endl;
  // other ways exist
  return 0;
}
