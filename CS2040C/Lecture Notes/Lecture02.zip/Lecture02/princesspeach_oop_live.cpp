// there is one character bug in this code, submitting it verbatim will give you Wrong Answer

#include <bits/stdc++.h> // to include everything
using namespace std; // dangerous

class obstacle_info { // please compare this version with princesspeach_live.cpp from previous week
private:
  bool found[110]; // data encapsulation/information hiding, we do not let others manipulate this boolean array directly
public:
  obstacle_info() {
    for (int i = 0; i < 110; i++) // optional actually
      found[i] = false;
  }
  void set(int k) {
    found[k] = true; // we only want one directional change, from a false to a true (or a true to still true), but NOT the other way (from a true to a false -> potential bug)
  }
  bool is_set(int i) {
    return found[i]; // as i is surely between [0..N-1], we won't have crash here
  }
};

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int N, Y; cin >> N >> Y;
  obstacle_info obstacle;
  for (int i = 0; i < Y; i++) {
    int k; cin >> k;
    obstacle.set(k);
    obstacle.found[1] = false; // trying my luck
  }
  int X = 0;
  for (int i = 0; i < N; i++)
    if (!obstacle.is_set(i))
      cout << i << endl;
    else
      X++;
  cout << "Mario got " << 0 << " of the dangerous obstacles.\n";
  return 0;
}
