// Conformity (coded in about 5m+), trivial...
// sort, STL map of SET to int, frequency counting (set will auto sort those 5 different ids into 5 sorted ids)
#include <bits/stdc++.h> // giveaway line 1
using namespace std; // giveaway line 2
int main() { // giveaway line 3
  // freopen("in_conformity.txt", "r", stdin); // just for testing, not part of the official 25 lines answer
  ios::sync_with_stdio(false); cin.tie(NULL); // giveaway line 4
  int n;
  cin >> n;
  map<set<int>, int> f; // note, canNOT use unordered_map as it does not able to 'hash' set<int> easily
  for (int i = 0; i < n; i++) {
    set<int> ids;
    for (int j = 0, id; j < 5; j++) { // read the 5 module ids
      cin >> id;
      ids.insert(id); // insert into C++ STL set -> AUTO SORT
    }
    ++f[ids]; // let C++ map do the actual frequency counting :O
  }
  int max_v = -1, ans = 0; // 2 lines into one
  for (auto &it : f) { // the business end, some of you got minor problem here
    if (it.second >  max_v) max_v = it.second, ans = 0; // two lines shortened into one using , :O (yea)
    if (it.second == max_v) ans += it.second;
  }
  cout << ans << endl;
  return 0; // giveaway line 5
} // giveaway line 6
