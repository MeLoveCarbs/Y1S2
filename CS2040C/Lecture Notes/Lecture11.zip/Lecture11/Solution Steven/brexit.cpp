// Brexit
// simulate, modified graph traversal, good

#include <bits/stdc++.h>
using namespace std;

typedef vector<int> vi;

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  int C, P, X, L; cin >> C >> P >> X >> L; --X; --L; // convert to 0-based indexing
  vi ori_degree(C);
  vi cur_degree(C);
  vi has_left(C);
  vector<vi> AL(C, vi());
  for (int i = 0; i < P; ++i) {
    int A, B; cin >> A >> B; --A; --B; // convert to 0-based indexing
    ori_degree[A]++;
    ori_degree[B]++;
    cur_degree[A]++;
    cur_degree[B]++;
    AL[A].push_back(B);
    AL[B].push_back(A); // bidirectional
  }
  queue<int> to_process; to_process.push(L); // L is the 'source' of the chain
  has_left[L] = true; // has_left is like the usual 'visited' flag
  while (!to_process.empty()) {
    A = to_process.front(); to_process.pop();
    if (A == X) break;
    for (auto &partner : AL[A]) {
      if (has_left[partner]) continue;
      --cur_degree[partner];
      if (2*cur_degree[partner] <= ori_degree[partner]) {
        has_left[partner] = true;
        to_process.push(partner);
      }
    }
  }
  cout << (has_left[X] ? "leave" : "stay") << endl;
  return 0;
}
