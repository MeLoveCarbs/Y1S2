// Build Dependencis
// parsing, DAG, input won't be cyclic, toposort/dfs from changed file

#include <bits/stdc++.h>
using namespace std;

typedef vector<string> vs;

unordered_map<string, vs> AL;
unordered_map<string, bool> vis;
vs toposort;

void dfs(string u) {
  vis[u] = true;
  for (auto &v : AL[u]) {
    if (vis.find(v) == vis.end()) {
      dfs(v);
    }
  }
  toposort.push_back(u);
}

int main() {
  int n; cin >> n; cin.get();
  AL.clear();
  for (int i = 0; i < n; ++i) {
    string line; getline(cin, line);
    stringstream ss(line);
    string file; ss >> file; file.pop_back(); // I don't want the :
    string dep;
    while (ss >> dep) {
      AL[dep].push_back(file);
    }
  }
  string file; getline(cin, file);
  dfs(file);
  reverse(toposort.begin(), toposort.end());
  for (auto &f : toposort) {
    cout << f << endl;
  }
  return 0;
}
