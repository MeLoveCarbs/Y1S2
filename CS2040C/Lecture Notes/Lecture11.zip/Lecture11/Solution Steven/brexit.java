// Brexit
// simulate, modified graph traversal, good problem

import java.io.*;
import java.util.*;

class brexit {
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    String[] token = br.readLine().split(" ");
    int C = Integer.parseInt(token[0]), P = Integer.parseInt(token[1]), X = Integer.parseInt(token[2])-1, L = Integer.parseInt(token[3])-1; // to 0-based indexing
    int[] degree = new int[C];
    int[] cur_degree = new int[C];
    Boolean[] has_left = new Boolean[C];
    ArrayList<ArrayList<Integer>> AL = new ArrayList<>();
    for (int A = 0; A < C; A++) {
      AL.add(new ArrayList<>());
      degree[A] = 0;
      cur_degree[A] = 0;
      has_left[A] = false;
    }
    while (P-- > 0) {
      token = br.readLine().split(" ");
      int A = Integer.parseInt(token[0])-1, B = Integer.parseInt(token[1])-1;
      degree[A]++;
      degree[B]++;
      cur_degree[A]++;
      cur_degree[B]++;
      AL.get(A).add(B);
      AL.get(B).add(A); // bi-directional
    }

    Queue<Integer> to_process = new LinkedList<Integer>();
    to_process.offer(L);
    has_left[L] = true; // the 'source' of the simulation chain
    while (!to_process.isEmpty()) {
      int A = to_process.poll();
      if (A == X) break;
      for (Integer partner : AL.get(A)) {
        if (has_left[partner]) continue;
        cur_degree[partner]--;
        if (2*cur_degree[partner] <= degree[partner]) { // better than cur_degree[partner] <= degree[partner]/2
          has_left[partner] = true;
          to_process.offer(partner);
        }
      }
    }
    pw.println(has_left[X] ? "leave" : "stay");

    pw.close();
  }
}
