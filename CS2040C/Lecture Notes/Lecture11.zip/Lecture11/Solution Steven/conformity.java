// Conformity (coded in about 5m+), trivial...
// sort, TreeMap of TreeSet to Integer, frequency counting (set will auto sort those 5 different ids into 5 sorted ids)

import java.io.*;
import java.util.*;

class conformity {
  public static void main(String[] args) throws Exception {
    FastScanner sc = new FastScanner(); // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    PrintWriter pw = new PrintWriter(System.out);

    int n = sc.nextInt();
    TreeMap<String, Integer> f = new TreeMap<String, Integer>();
    for (int i = 0; i < n; i++) {
      ArrayList<String> ids = new ArrayList<String>();
      for (int j = 0; j < 5; j++) // read the 5 module ids
        ids.add(sc.next());
      Collections.sort(ids); // sort ascending
      String code = "";
      for (int j = 0; j < 5; j++) // concatenate 5 sorted module ids
        code += ids.get(j);
      if (f.get(code) == null)
        f.put(code, 1);
      else
        f.put(code, f.get(code)+1); // let TreeMap do the actual frequency counting :O
    }
    int max_v = -1, ans = 0; // 2 lines into one
    for (Map.Entry<String, Integer> it : f.entrySet()) { // the business end, some of you got minor problem here
      if (it.getValue() >  max_v) {
        max_v = it.getValue();
        ans = 0;
      }
      if (it.getValue() == max_v) ans += it.getValue();
    }
    pw.println(ans);

    pw.close();
  }



  static class FastScanner {
    BufferedReader br;
    StringTokenizer st;

    public FastScanner() {
      br = new BufferedReader(new InputStreamReader(System.in));
    }

    String next() {
      while (st == null || !st.hasMoreElements()) {
        try {
          st = new StringTokenizer(br.readLine());
        }
        catch (IOException e) {
          e.printStackTrace();
        }
      }
      return st.nextToken();
    }

    int nextInt() { return Integer.parseInt(next()); }
    long nextLong() { return Long.parseLong(next()); }
    double nextDouble() { return Double.parseDouble(next()); }
      
    String nextLine() {
      String str = "";
      try {
        str = br.readLine();
      }
      catch (IOException e) {
        e.printStackTrace();
      }
      return str;
    }
  }
}
