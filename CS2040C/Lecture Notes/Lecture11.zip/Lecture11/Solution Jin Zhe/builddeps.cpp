#include <bits/stdc++.h>
using namespace std;

typedef vector<string> vecstr;

/* Global variables */
unordered_map<string, vecstr> AL; // Adjacency list
unordered_set<string> visited;    // Visited hashset
list<string> tps;                 // Toposort list

/* Toposort */
void toposort(string source){
  if (visited.count(source) != 0) return;
  visited.insert(source); // Mark visited
  for (auto & dependent : AL[source]) {
    toposort(dependent);
  }
  tps.push_front(source); // Prepend to toposort list
}

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);

  /* Read inputs and populate adjacency list */
  int n; cin >> n; cin.get();
  while(n--) {
    string line; getline(cin, line);
    istringstream iss(line);

    /* Read dependent */
    string dependent; iss >> dependent;
    dependent.pop_back(); // Remove colon suffix
    
    /* Read all depdendencies and store dependent as their neighbour */
    string dependency;
    while(iss >> dependency) {
      AL[dependency].push_back(dependent);
    }
  }

  /* Read query */
  string query; cin >> query;
  
  /* Run toposort */
  toposort(query);

  /* Output */
  for (auto &source : tps) {
    cout << source << endl;
  }
}