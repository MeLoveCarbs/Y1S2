#include <bits/stdc++.h>
using namespace std;

typedef set<int> setint;

/* Global variables */
multiset<setint> popularity;  // Tracks popularity of each subject combination

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);
  
  /* Read inputs */
  int n; cin >> n;
  int most_popular = 0; // Tracks the subscription count of the most popular subject combination
  while (n--) {
    /* Read in subject combination of current student */
    setint cmb;
    int mod;
    for (int i=0; i<5; i++) {
      cin >> mod;
      cmb.insert(mod);
    }

    /* Insert subject combination into popularity */
    popularity.insert(cmb);

    /* Update most_popular */
    most_popular = max(most_popular, (int) popularity.count(cmb));
  }

  /* Calculate answer */
  int ans = 0;  // Accumulator
  /* Goes through all subject combinations in popularity */
  for (auto &i : popularity) {
    /* Increment ans if currently at a most popular subject */
    if (popularity.count(i) == most_popular) ans++;
  }

  /* Output */
  cout << ans << endl;
}