#include <bits/stdc++.h>
using namespace std;

typedef set<int> setint;

/* Global variables */
vector<setint> AL(200001);    // Adjacency list
vector<int> original(200001); // ADT for original vertex degrees

/* Helper functions */

/* Checks if a country will leave based on its current trade partnerships */
bool is_leaving(int c_id) {
  return AL[c_id].size() <= original[c_id]/2;
}

/* Remove country a from country b's trade partnerships */
void remove_from(int a, int b){
  auto it = AL[b].find(a);
  AL[b].erase(it);
}

/* Removes a country from the trade union */
void remove_country(int c_id) {
  setint & partners = AL[c_id];
  for (auto p_id : partners) {
    remove_from(c_id, p_id);
  }
  AL[c_id].clear();
}

/* Our modified BFS to set off the chain of cascading doom */
void cascade_doom(int traitor_id){
  queue<int> q;
  q.push(traitor_id);
  while(q.size()) {
    int c_id = q.front(); q.pop();
    /* if country c_id is leaving the union */
    if (is_leaving(c_id) || c_id == traitor_id) {
      for (auto &partner_id : AL[c_id]) q.push(partner_id);
      remove_country(c_id);
    }
  }
}

int main() {
  ios::sync_with_stdio(false); cin.tie(NULL);

  /* Read inputs */
  int C, P, X, L;
  cin >> C >> P >> X >> L;
  /* Populate adjacency list */ 
  while (P--) {
    int a, b; cin >> a >> b;
    /* Update the partners of both a and b because undirected graph */
    AL[a].insert(b); // Add b to a's partners
    AL[b].insert(a); // Add a to b's partners
  }

  /* Populate original */
  for (int i=0; i<=C; ++i) {
    original[i] = AL[i].size(); // Original partnership count of each country
  }

  /* Set off the chain of cascading doom */
  cascade_doom(L);

  /* Output */
  if (is_leaving(X))
    cout << "leave" << endl;
  else
    cout << "stay" << endl;
}